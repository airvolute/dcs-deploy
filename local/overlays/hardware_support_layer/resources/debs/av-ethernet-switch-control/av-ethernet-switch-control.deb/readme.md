# Setup script for KSZ9896C switches with Airvolute DroneCore 2

## installation
Copy the project into device eg. by scp. 

## requirements
`pip3 install smbus2`  
or  
`pip3 install -r requirements.txt`  
if not insalled `pip3`, but default python is v3 use `pip`  
Tested with python3.8

## usage
Run the script `python3 set_phy_registers.py`

## configuration
See config file [switch_cfg.yaml](switch_cfg.yaml) and read notes to each parameter. The best place for configuration file location is in `/etc/airvolute/`
